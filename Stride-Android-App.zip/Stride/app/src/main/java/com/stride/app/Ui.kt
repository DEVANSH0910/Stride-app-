package com.stride.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.text.SimpleDateFormat
import java.util.*

object Pal { var dark = false }
val Org = Color(0xFFFC4C02); val Dk = Color(0xFF14161A)
val Bg: Color get() = if (Pal.dark) Color(0xFF0F1114) else Color(0xFFF4F4F6)
val Surf: Color get() = if (Pal.dark) Color(0xFF1B1E23) else Color.White
val Ink: Color get() = if (Pal.dark) Color(0xFFF2F3F5) else Color(0xFF242428)
val Mu: Color get() = if (Pal.dark) Color(0xFF9AA1AB) else Color(0xFF62626C)
val Line: Color get() = if (Pal.dark) Color(0xFF2E3238) else Color(0xFFE6E6EA)
val ING = listOf("Walking", "Jogging", "Running")

fun fmtT(s: Int) = if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
fun fmtP(s: Double): String { if (s.isNaN() || s.isInfinite() || s <= 0 || s > 1800) return "–"; val r = s.toInt(); return "%d:%02d".format(r / 60, r % 60) }
fun weekStart(): Long {
    val c = Calendar.getInstance(); c.firstDayOfWeek = Calendar.MONDAY; c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); return c.timeInMillis
}
fun monthStart(): Long {
    val c = Calendar.getInstance(); c.set(Calendar.DAY_OF_MONTH, 1)
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); return c.timeInMillis
}
fun fmtD(ts: Long) = SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault()).format(Date(ts))
fun dayKey(ts: Long): Int { val c = Calendar.getInstance(); c.timeInMillis = ts; return c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR) }
fun streak(a: List<Act>): Int {
    val set = a.map { dayKey(it.start) }.toSet(); val c = Calendar.getInstance()
    if (dayKey(c.timeInMillis) !in set) c.add(Calendar.DAY_OF_YEAR, -1)
    var n = 0
    while (dayKey(c.timeInMillis) in set) { n++; c.add(Calendar.DAY_OF_YEAR, -1) }
    return n
}
fun title(a: Act): String {
    val h = Calendar.getInstance().apply { timeInMillis = a.start }.get(Calendar.HOUR_OF_DAY)
    return (if (h < 5) "Night" else if (h < 12) "Morning" else if (h < 17) "Afternoon" else if (h < 21) "Evening" else "Night") + " " + a.type
}

@Composable fun Card2(m: Modifier = Modifier, c: @Composable ColumnScope.() -> Unit) =
    Column(m.fillMaxWidth().shadow(2.dp, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(Surf), content = c)

@Composable fun Stat(l: String, v: String, u: String = "", dark: Boolean = false) = Column {
    Text(l, fontSize = 12.sp, color = Mu)
    Row(verticalAlignment = Alignment.Bottom) {
        Text(v, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = if (dark) Color.White else Ink)
        if (u.isNotEmpty()) Text(" $u", fontSize = 13.sp, color = Mu)
    }
}
@Composable fun Cell(l: String, v: String, m: Modifier = Modifier) = Column(m.padding(horizontal = 8.dp)) {
    Text(l, fontSize = 12.sp, color = Mu); Text(v, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
}
@Composable fun Div() = Box(Modifier.width(1.dp).height(34.dp).background(Line))
@Composable fun Avatar(s: Int = 40) = Box(Modifier.size(s.dp).clip(CircleShape).background(Org), Alignment.Center) {
    Text("Y", color = Color.White, fontWeight = FontWeight.Bold, fontSize = (s * 0.42).sp)
}
@Composable fun Tile(l: String, v: String, m: Modifier = Modifier) = Card2(m) {
    Column(Modifier.padding(12.dp)) { Text(l, fontSize = 12.sp, color = Mu); Text(v, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold) }
}

fun DrawScope.mapBg() {
    drawRect(if (Pal.dark) Color(0xFF1E2125) else Color(0xFFE8EBE4))
    drawRect(if (Pal.dark) Color(0xFF1E2F27) else Color(0xFFD3E5CB), Offset(size.width * .62f, size.height * .08f), Size(size.width * .28f, size.height * .34f))
    val rv = Path().apply { moveTo(-10f, size.height * .82f); cubicTo(size.width * .3f, size.height * .6f, size.width * .6f, size.height, size.width + 10f, size.height * .7f) }
    drawPath(rv, if (Pal.dark) Color(0xFF1B3341) else Color(0xFFC9E0EE), style = Stroke(40f))
    var x = 0f; while (x < size.width) { drawLine(if (Pal.dark) Color(0xFF343A41) else Color.White, Offset(x, 0f), Offset(x, size.height), 6f); x += size.width / 5f }
    var y = 0f; while (y < size.height) { drawLine(if (Pal.dark) Color(0xFF343A41) else Color.White, Offset(0f, y), Offset(size.width, y), 6f); y += size.height / 3f }
}

@Composable fun RouteThumb(r: List<Pt>) {
    Canvas(Modifier.fillMaxWidth().height(160.dp)) {
        mapBg()
        if (r.size < 2) return@Canvas
        val la0 = r.minOf { it.lat }; val la1 = r.maxOf { it.lat }; val lo0 = r.minOf { it.lon }; val lo1 = r.maxOf { it.lon }
        val k = Math.cos(Math.toRadians((la0 + la1) / 2)); val w = maxOf((lo1 - lo0) * k, 1e-6); val h = maxOf(la1 - la0, 1e-6)
        val s = minOf((size.width - 60f) / w, (size.height - 60f) / h)
        val ox = (size.width - w * s) / 2; val oy = (size.height - h * s) / 2
        val pts = r.map { Offset((ox + (it.lon - lo0) * k * s).toFloat(), (oy + (la1 - it.lat) * s).toFloat()) }
        val p = Path(); pts.forEachIndexed { i, o -> if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
        drawPath(p, Color(0x44FC4C02), style = Stroke(28f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(p, Org, style = Stroke(9f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(Color.White, 15f, pts.first()); drawCircle(Color(0xFF1E9E4F), 10f, pts.first())
        drawCircle(Color.White, 15f, pts.last()); drawCircle(Color(0xFF242428), 10f, pts.last())
    }
}

@Composable fun MapTrack(pts: List<Pt>, m: Modifier, fit: Boolean, others: List<List<Pt>> = emptyList()) {
    val ctx = LocalContext.current
    val mv = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK); setMultiTouchControls(true); controller.setZoom(17.0)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        }
    }
    DisposableEffect(Unit) { onDispose { mv.onDetach() } }
    AndroidView({ mv }, m) { v ->
        v.overlayManager.tilesOverlay.setColorFilter(if (Pal.dark) TilesOverlay.INVERT_COLORS else null)
        v.overlays.clear()
        for (o in others) if (o.size > 1) v.overlays.add(Polyline().apply {
            setPoints(o.map { GeoPoint(it.lat, it.lon) }); outlinePaint.color = 0xAAFC4C02.toInt(); outlinePaint.strokeWidth = 9f
        })
        val g = pts.map { GeoPoint(it.lat, it.lon) }
        if (g.size > 1) v.overlays.add(Polyline().apply { setPoints(g); outlinePaint.color = 0xFFFC4C02.toInt(); outlinePaint.strokeWidth = 14f })
        val all = g + others.flatten().map { GeoPoint(it.lat, it.lon) }
        if (all.isNotEmpty()) {
            if (fit && all.size > 1) { val bb = BoundingBox.fromGeoPoints(all); v.post { v.zoomToBoundingBox(bb, false, 80) } }
            else if (g.isNotEmpty()) v.controller.setCenter(g.last())
        }
        v.invalidate()
    }
}

@Composable fun NavItem(l: String, ic: ImageVector, sel: Boolean, on: () -> Unit) =
    Column(Modifier.clickable(onClick = on).padding(horizontal = 10.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(ic, l, tint = if (sel) Org else Mu, modifier = Modifier.size(24.dp))
        Text(l, fontSize = 11.sp, color = if (sel) Org else Mu, fontWeight = FontWeight.SemiBold)
    }

@Composable fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    Column(Modifier.background(Surf)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
        Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 8.dp), Arrangement.SpaceAround, Alignment.CenterVertically) {
            NavItem("Home", Icons.Filled.Home, tab == 0) { onTab(0) }
            NavItem("Routes", Icons.Filled.Place, tab == 1) { onTab(1) }
            Box(Modifier.size(52.dp).clip(CircleShape).background(Org).clickable { onTab(2) }, Alignment.Center) {
                Box(Modifier.size(20.dp).border(3.dp, Color.White, CircleShape))
            }
            NavItem("Goals", Icons.Filled.Star, tab == 3) { onTab(3) }
            NavItem("You", Icons.Filled.Person, tab == 4) { onTab(4) }
        }
    }
}

@Composable fun Home(a: List<Act>, goal: Int, open: (Long) -> Unit, share: (Act) -> Unit) {
    val wk = a.filter { it.start >= weekStart() }.sumOf { it.km }
    val active = (0..6).map { d -> val k = dayKey(weekStart() + d * 86400000L + 43200000L); a.any { dayKey(it.start) == k } }
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth().background(Surf).padding(horizontal = 16.dp, vertical = 12.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Stride", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Org)
                Box(Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0x1AFC4C02)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Text("${streak(a)}-day streak", color = Org, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        item {
            Card2(Modifier.padding(horizontal = 12.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("This week", color = Mu, fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("%.1f".format(wk), fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                        Text(" km of $goal km", color = Mu, modifier = Modifier.padding(bottom = 7.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { (wk / goal).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Org, trackColor = Line)
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        "MTWTFSS".forEachIndexed { i, ch ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(26.dp).clip(CircleShape).background(if (active[i]) Org else Line))
                                Text(ch.toString(), fontSize = 11.sp, color = Mu)
                            }
                        }
                    }
                }
            }
        }
        if (a.isEmpty()) item { Text("No activities yet. Tap the orange Record button to start your first one.", color = Mu, modifier = Modifier.padding(16.dp)) }
        items(a, key = { it.id }) { x ->
            Card2(Modifier.padding(horizontal = 12.dp).clickable { open(x.id) }) {
                Row(Modifier.padding(start = 14.dp, top = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("You", fontWeight = FontWeight.Bold)
                        Text(fmtD(x.start) + if (x.src == "health") " · Health Connect" else "", fontSize = 12.sp, color = Mu)
                    }
                    IconButton({ share(x) }) { Icon(Icons.Filled.Share, "Share", tint = Mu) }
                }
                Text(title(x), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp))
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Cell("Distance", "%.2f km".format(x.km), Modifier.weight(1f)); Div()
                    Cell("Pace", fmtP(x.dur / x.km) + " /km", Modifier.weight(1f)); Div()
                    Cell("Time", fmtT(x.dur), Modifier.weight(1f))
                }
                if (x.elev > 0 || x.steps > 0) Text(extraLine(x), fontSize = 13.sp, color = Mu, modifier = Modifier.padding(start = 14.dp, bottom = 10.dp))
                if (x.route.size > 1) RouteThumb(x.route)
            }
        }
    }
}

@Composable fun Record(ts: TS, send: (String) -> Unit) {
    if (!ts.on) {
        Box(Modifier.fillMaxSize()) {
            Canvas(Modifier.fillMaxSize()) { mapBg() }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().shadow(14.dp, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).background(Surf).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Line))
                Spacer(Modifier.height(16.dp))
                Box(Modifier.clip(RoundedCornerShape(18.dp)).background(Ink).padding(horizontal = 18.dp, vertical = 9.dp)) {
                    Text("Auto-detect: walk, jog or run", color = Bg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(Modifier.height(20.dp))
                Box(Modifier.size(140.dp).clip(CircleShape).background(Color(0x26FC4C02)), Alignment.Center) {
                    Button({ send("START") }, Modifier.size(108.dp), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Org)) {
                        Text("START", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Your activity type is detected from your speed.", color = Mu, fontSize = 13.sp)
            }
        }
    } else Column(Modifier.fillMaxSize().background(Dk)) {
        MapTrack(ts.pts, Modifier.fillMaxWidth().weight(1f), false)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(Dk).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (ts.paused) "Paused" else if (!ts.gps) "Finding GPS signal…" else if (ts.kind < 0) "Start moving" else ING[ts.kind], color = Color(0xFFA5ABB5))
            Text(fmtT(ts.elapsed), fontSize = 70.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.SpaceEvenly) {
                Stat("Distance km", "%.2f".format(ts.km), dark = true)
                Stat("Avg /km", fmtP(ts.elapsed / ts.km), dark = true)
                Stat("Now /km", fmtP(ts.nowPace.toDouble()), dark = true)
            }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), Arrangement.SpaceEvenly) {
                Stat("Elevation m", "${ts.gain}", dark = true); Stat("Steps", "${ts.steps}", dark = true)
            }
            Spacer(Modifier.height(18.dp))
            if (ts.paused) Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button({ send("RESUME") }, colors = ButtonDefaults.buttonColors(containerColor = Org)) { Text("Resume", fontWeight = FontWeight.Bold) }
                OutlinedButton({ send("FINISH") }) { Text("Finish", color = Color.White) }
            } else Button({ send("PAUSE") }, Modifier.size(92.dp), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Org), contentPadding = PaddingValues(0.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(width = 9.dp, height = 30.dp).background(Dk, RoundedCornerShape(2.dp)))
                    Box(Modifier.size(width = 9.dp, height = 30.dp).background(Dk, RoundedCornerShape(2.dp)))
                }
            }
        }
    }
}

@Composable fun Routes(a: List<Act>) {
    val rs = a.map { it.route }.filter { it.size > 1 }
    Column(Modifier.fillMaxSize().background(Surf)) {
        Text("Your routes", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(16.dp))
        if (rs.isEmpty()) Text("Routes from your activities appear here on a map.", color = Mu, modifier = Modifier.padding(16.dp))
        else MapTrack(emptyList(), Modifier.fillMaxWidth().weight(1f), true, rs)
    }
}

@Composable fun Detail(a: Act, back: () -> Unit, del: () -> Unit, share: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Surf).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            TextButton(back) { Text("‹ Back", color = Org, fontWeight = FontWeight.Bold) }
            IconButton(share) { Icon(Icons.Filled.Share, "Share", tint = Mu) }
        }
        if (a.route.size > 1) MapTrack(a.route, Modifier.fillMaxWidth().height(300.dp), true)
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(); Spacer(Modifier.width(10.dp))
                Column { Text(title(a), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Text(fmtD(a.start), color = Mu, fontSize = 13.sp) }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Bg).padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Cell("Distance", "%.2f km".format(a.km), Modifier.weight(1f)); Div()
                Cell("Pace", fmtP(a.dur / a.km) + " /km", Modifier.weight(1f)); Div()
                Cell("Time", fmtT(a.dur), Modifier.weight(1f))
            }
            if (a.elev > 0 || a.steps > 0) Row(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(14.dp)).background(Bg).padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Cell("Elevation gain", "${a.elev} m", Modifier.weight(1f)); Div(); Cell("Steps", "${a.steps}", Modifier.weight(1f))
            }
            RunCharts(a)
            if (a.splits.isNotEmpty()) {
                Spacer(Modifier.height(16.dp)); Text("Splits", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                a.splits.forEachIndexed { i, s ->
                    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("km ${i + 1}", Modifier.width(48.dp), color = Mu, fontSize = 13.sp)
                        Box(Modifier.weight(1f)) { Box(Modifier.fillMaxWidth(((460 - s) / 120f).coerceIn(0.1f, 1f)).height(20.dp).clip(RoundedCornerShape(5.dp)).background(Org)) }
                        Text(fmtP(s.toDouble()), Modifier.width(48.dp), fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (a.sp.sum() > 0) {
                Spacer(Modifier.height(12.dp))
                ING.forEachIndexed { i, n -> if (a.sp[i] > 0) Text("$n  ${fmtT(a.sp[i])}", color = Mu) }
            }
            TextButton(del) { Text("Delete activity", color = Color(0xFFB3392F)) }
        }
    }
}

@Composable fun Goals(a: List<Act>, goal: Int, setGoal: (Int) -> Unit) {
    val wk = a.filter { it.start >= weekStart() }.sumOf { it.km }
    val month = a.filter { it.start >= monthStart() }.sumOf { it.km }
    val best = a.filter { it.km >= 1 && (it.type == "Run" || it.type == "Jog") }.minOfOrNull { it.dur / it.km }
    val longest = a.maxOfOrNull { it.km } ?: 0.0
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Goals", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Card2 {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Box(Modifier.size(140.dp), Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val tl = Offset(14f, 14f); val sz = Size(size.width - 28f, size.height - 28f)
                        drawArc(Line, 0f, 360f, false, tl, sz, style = Stroke(28f))
                        drawArc(Org, -90f, 360f * (wk / goal).toFloat().coerceIn(0f, 1f), false, tl, sz, style = Stroke(28f, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("%.1f".format(wk), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold); Text("of $goal km", fontSize = 12.sp, color = Mu)
                    }
                }
                Column {
                    Text("Weekly goal", color = Mu, fontSize = 13.sp)
                    Text(if (wk >= goal) "Goal reached!" else "%.1f km to go".format(goal - wk), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
        Card2 {
            Row(Modifier.fillMaxWidth().padding(16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Change goal", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton({ setGoal(maxOf(1, goal - 1)) }) { Text("−") }
                    Text("$goal km", fontWeight = FontWeight.ExtraBold)
                    Button({ setGoal(goal + 1) }, colors = ButtonDefaults.buttonColors(containerColor = Org)) { Text("+") }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Streak", "${streak(a)} days", Modifier.weight(1f)); Tile("Best pace", best?.let { fmtP(it) } ?: "–", Modifier.weight(1f)); Tile("Longest", "%.1f km".format(longest), Modifier.weight(1f))
        }
        Tile("This month", "%.1f km".format(month))
    }
}

@Composable fun You(a: List<Act>, steps: Long?, msg: String, theme: Int, setTheme: (Int) -> Unit, connect: () -> Unit, import: () -> Unit, upd: Upd, onCheck: () -> Unit) {
    val days = (6 downTo 0).map { d ->
        val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, -d); val key = dayKey(c.timeInMillis)
        "SMTWTFS"[c.get(Calendar.DAY_OF_WEEK) - 1].toString() to a.filter { dayKey(it.start) == key }.sumOf { it.km }
    }
    val mx = maxOf(days.maxOf { it.second }, 1.0)
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
            Avatar(64); Spacer(Modifier.width(14.dp))
            Column { Text("You", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold); Text("${a.size} activities", color = Mu) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Distance", "%.1f km".format(a.sumOf { it.km }), Modifier.weight(1f))
            Tile("Time", fmtT(a.sumOf { it.dur }), Modifier.weight(1f))
            Tile("Steps today", "${steps ?: "–"}", Modifier.weight(1f))
        }
        Card2 {
            Column(Modifier.padding(16.dp)) {
                Text("Last 7 days", fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth().height(110.dp).padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    days.forEachIndexed { i, (l, km) ->
                        Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.Bottom, Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().height(maxOf(4.0, km / mx * 80).dp).clip(RoundedCornerShape(6.dp)).background(if (i == 6) Org else Line))
                            Text(l, fontSize = 11.sp, color = Mu)
                        }
                    }
                }
            }
        }
        Card2 {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Appearance", fontWeight = FontWeight.ExtraBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("System", "Light", "Dark").forEachIndexed { i, n ->
                        if (theme == i) Button({ setTheme(i) }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Org), contentPadding = PaddingValues(0.dp)) { Text(n) }
                        else OutlinedButton({ setTheme(i) }, Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text(n) }
                    }
                }
            }
        }
        Card2 {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val cx = LocalContext.current
                var cal by remember { mutableStateOf(Store.calib(cx)) }
                Text("Distance calibration", fontWeight = FontWeight.ExtraBold)
                Text("If Stride reads shorter or longer than Samsung Health, adjust it here. It applies to new activities.", color = Mu, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton({ cal = maxOf(80, cal - 1); Store.setCalib(cx, cal) }) { Text("−") }
                    Text("$cal%", fontWeight = FontWeight.ExtraBold)
                    Button({ cal = minOf(125, cal + 1); Store.setCalib(cx, cal) }, colors = ButtonDefaults.buttonColors(containerColor = Org)) { Text("+") }
                }
            }
        }
        Card2 {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Samsung Health sync", fontWeight = FontWeight.ExtraBold)
                Text("Finished activities are saved to Health Connect, which Samsung Health can read. Workouts from Samsung Health can be imported back.", color = Mu, fontSize = 13.sp)
                Button(connect, colors = ButtonDefaults.buttonColors(containerColor = Org)) { Text("Connect Health Connect") }
                OutlinedButton(import) { Text("Import workouts from Samsung Health") }
                if (msg.isNotEmpty()) Text(msg, color = Org, fontSize = 13.sp)
            }
        }
        Card2 {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("App updates", fontWeight = FontWeight.ExtraBold)
                Text("Version ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})", color = Mu, fontSize = 13.sp)
                OutlinedButton(onCheck) { Text(if (upd.checking) "Checking…" else "Check for updates") }
                if (upd.msg.isNotEmpty()) Text(upd.msg, color = Org, fontSize = 13.sp)
            }
        }
    }
}

fun extraLine(a: Act) = listOfNotNull(if (a.elev > 0) "Elevation ${a.elev} m" else null, if (a.steps > 0) "${a.steps} steps" else null).joinToString(" · ")
