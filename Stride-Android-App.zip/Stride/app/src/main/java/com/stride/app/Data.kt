package com.stride.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class Pt(val lat: Double, val lon: Double)
data class Act(val id: Long, val start: Long, val dur: Int, val km: Double, val type: String,
               val route: List<Pt>, val splits: List<Int>, val sp: List<Int>, val src: String, val elev: Int = 0, val steps: Int = 0)

object Store {
    private val g = Gson()
    private fun p(c: Context) = c.getSharedPreferences("stride", 0)
    fun all(c: Context): List<Act> = try {
        g.fromJson<List<Act>>(p(c).getString("acts", "[]"), object : TypeToken<List<Act>>() {}.type) ?: emptyList()
    } catch (e: Exception) { emptyList() }
    fun save(c: Context, l: List<Act>) { p(c).edit().putString("acts", g.toJson(l)).apply() }
    fun goal(c: Context) = p(c).getInt("goal", 15)
    fun setGoal(c: Context, g: Int) { p(c).edit().putInt("goal", g).apply() }
    fun theme(c: Context) = p(c).getInt("theme", 0)
    fun setTheme(c: Context, t: Int) { p(c).edit().putInt("theme", t).apply() }
    fun add(c: Context, a: Act) = save(c, (all(c) + a).sortedByDescending { it.start })
}
