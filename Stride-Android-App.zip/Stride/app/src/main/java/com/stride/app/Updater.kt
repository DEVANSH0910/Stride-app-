package com.stride.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Upd(val avail: Boolean = false, val code: Int = 0, val url: String = "", val notes: String = "",
               val progress: Int = -1, val msg: String = "", val checking: Boolean = false)

object Updater {
    val s = MutableStateFlow(Upd())

    suspend fun check(manual: Boolean) {
        if (BuildConfig.REPO.isEmpty()) { if (manual) s.value = s.value.copy(msg = "Updates are not set up for this build."); return }
        s.value = s.value.copy(checking = true, msg = "")
        val r = withContext(Dispatchers.IO) {
            try {
                val c = URL("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                c.setRequestProperty("Accept", "application/vnd.github+json"); c.setRequestProperty("User-Agent", "Stride")
                if (c.responseCode != 200) return@withContext null
                val o = JsonParser.parseString(c.inputStream.bufferedReader().readText()).asJsonObject
                val code = o.get("tag_name").asString.filter { it.isDigit() }.toInt()
                var url = ""
                for (x in o.getAsJsonArray("assets")) { val a = x.asJsonObject; if (a.get("name").asString.endsWith(".apk")) url = a.get("browser_download_url").asString }
                val nb = o.get("body")
                Triple(code, url, if (nb == null || nb.isJsonNull) "" else nb.asString)
            } catch (e: Exception) { null }
        }
        if (r == null) { s.value = s.value.copy(checking = false, msg = if (manual) "Could not check for updates. Check your internet connection." else ""); return }
        if (r.first > BuildConfig.VERSION_CODE && r.second.isNotEmpty()) s.value = Upd(avail = true, code = r.first, url = r.second, notes = r.third)
        else s.value = s.value.copy(checking = false, msg = if (manual) "You are on the latest version." else "")
    }

    suspend fun download(c: Context) {
        val u = s.value
        if (Build.VERSION.SDK_INT >= 26 && !c.packageManager.canRequestPackageInstalls()) {
            s.value = u.copy(msg = "Allow Stride to install updates, then come back and tap Update now.")
            c.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        s.value = u.copy(progress = 0, msg = "")
        val f = withContext(Dispatchers.IO) {
            try {
                val out = File(File(c.cacheDir, "updates").apply { mkdirs() }, "stride.apk")
                val k = URL(u.url).openConnection() as HttpURLConnection
                k.connectTimeout = 15000; k.readTimeout = 30000
                val total = k.contentLength.toLong(); var got = 0L; var last = -1
                k.inputStream.use { i ->
                    out.outputStream().use { o ->
                        val b = ByteArray(16384)
                        while (true) {
                            val n = i.read(b); if (n < 0) break
                            o.write(b, 0, n); got += n
                            if (total > 0) { val p = (got * 100 / total).toInt(); if (p != last) { last = p; s.value = s.value.copy(progress = p) } }
                        }
                    }
                }
                out
            } catch (e: Exception) { null }
        }
        if (f == null) { s.value = s.value.copy(progress = -1, msg = "Download failed. Please try again."); return }
        s.value = s.value.copy(progress = -1)
        val uri = FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", f)
        c.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
