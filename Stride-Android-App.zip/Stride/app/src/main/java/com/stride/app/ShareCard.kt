package com.stride.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MapImg(val bmp: Bitmap, val proj: (Double, Double) -> PointF)

object ShareCard {
    private const val MW = 1080
    private const val MH = 780
    private val cache = HashMap<Long, MapImg>()
    private fun wx(lon: Double, z: Int) = (lon + 180) / 360 * 256 * (1 shl z)
    private fun wy(lat: Double, z: Int): Double {
        val r = Math.toRadians(lat); return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * 256 * (1 shl z)
    }

    suspend fun loadMap(a: Act): MapImg? = withContext(Dispatchers.IO) {
        cache[a.id] ?: (try { fetch(a.route) } catch (e: Exception) { null })?.also { cache[a.id] = it }
    }

    private fun fetch(r: List<Pt>): MapImg? {
        if (r.size < 2) return null
        val la0 = r.minOf { it.lat }; val la1 = r.maxOf { it.lat }; val lo0 = r.minOf { it.lon }; val lo1 = r.maxOf { it.lon }
        var z = 17
        while (z > 3 && (wx(lo1, z) - wx(lo0, z) > MW * 0.7 || wy(la0, z) - wy(la1, z) > MH * 0.7)) z--
        val cx = (wx(lo0, z) + wx(lo1, z)) / 2; val cy = (wy(la0, z) + wy(la1, z)) / 2
        val left = cx - MW / 2; val top = cy - MH / 2; val n = 1 shl z
        val bmp = Bitmap.createBitmap(MW, MH, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp); cv.drawColor(0xFFE8EBE4.toInt())
        var got = 0
        for (tx in Math.floor(left / 256).toInt()..Math.floor((left + MW) / 256).toInt()) {
            for (ty in Math.floor(top / 256).toInt()..Math.floor((top + MH) / 256).toInt()) {
                if (ty < 0 || ty >= n) continue
                val xx = ((tx % n) + n) % n
                try {
                    val c = URL("https://tile.openstreetmap.org/$z/$xx/$ty.png").openConnection() as HttpURLConnection
                    c.setRequestProperty("User-Agent", "Stride/1.0 (Android fitness app)"); c.connectTimeout = 8000; c.readTimeout = 8000
                    val t = BitmapFactory.decodeStream(c.inputStream)
                    if (t != null) { cv.drawBitmap(t, (tx * 256 - left).toFloat(), (ty * 256 - top).toFloat(), null); got++ }
                } catch (e: Exception) { }
            }
        }
        if (got == 0) return null
        return MapImg(bmp) { lat, lon -> PointF((wx(lon, z) - left).toFloat(), (wy(lat, z) - top).toFloat()) }
    }

    fun loadPhoto(c: Context, u: Uri): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1; while (maxOf(o.outWidth, o.outHeight) / s > 2200) s *= 2
        c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }
    } catch (e: Exception) { null }

    private fun fit(r: List<Pt>, rc: RectF): List<PointF> {
        if (r.size < 2) return emptyList()
        val la0 = r.minOf { it.lat }; val la1 = r.maxOf { it.lat }; val lo0 = r.minOf { it.lon }; val lo1 = r.maxOf { it.lon }
        val k = Math.cos(Math.toRadians((la0 + la1) / 2)); val w = maxOf((lo1 - lo0) * k, 1e-6); val h = maxOf(la1 - la0, 1e-6)
        val s = minOf(rc.width() / w, rc.height() / h); val ox = rc.left + (rc.width() - w * s) / 2; val oy = rc.top + (rc.height() - h * s) / 2
        return r.map { PointF((ox + (it.lon - lo0) * k * s).toFloat(), (oy + (la1 - it.lat) * s).toFloat()) }
    }

    private fun grid(cv: Canvas, rc: RectF, dark: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = if (dark) 0xFF1E2125.toInt() else 0xFFE8EBE4.toInt(); cv.drawRect(rc, p)
        p.color = if (dark) 0xFF1E2F27.toInt() else 0xFFD3E5CB.toInt()
        cv.drawRect(rc.left + rc.width() * .62f, rc.top + rc.height() * .08f, rc.left + rc.width() * .9f, rc.top + rc.height() * .42f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 10f; p.color = if (dark) 0xFF343A41.toInt() else Color.WHITE
        var x = rc.left; while (x <= rc.right) { cv.drawLine(x, rc.top, x, rc.bottom, p); x += rc.width() / 5f }
        var y = rc.top; while (y <= rc.bottom) { cv.drawLine(rc.left, y, rc.right, y, p); y += rc.height() / 3f }
    }

    private fun route(cv: Canvas, pts: List<PointF>, main: Int, outline: Int?, w: Float) {
        if (pts.size < 2) return
        val path = Path(); pts.forEachIndexed { i, o -> if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
        val p = Paint(Paint.ANTI_ALIAS_FLAG); p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        if (outline != null) { p.color = outline; p.strokeWidth = w + 16f } else { p.color = (main and 0x00FFFFFF) or 0x55000000; p.strokeWidth = w + 24f }
        cv.drawPath(path, p); p.color = main; p.strokeWidth = w; cv.drawPath(path, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE; cv.drawCircle(pts.first().x, pts.first().y, 24f, p); p.color = 0xFF1E9E4F.toInt(); cv.drawCircle(pts.first().x, pts.first().y, 16f, p)
        p.color = Color.WHITE; cv.drawCircle(pts.last().x, pts.last().y, 24f, p); p.color = 0xFF242428.toInt(); cv.drawCircle(pts.last().x, pts.last().y, 16f, p)
    }

    private fun cover(cv: Canvas, b: Bitmap, W: Int, H: Int) {
        val s = maxOf(W / b.width.toFloat(), H / b.height.toFloat()); val m = Matrix()
        m.postScale(s, s); m.postTranslate((W - b.width * s) / 2, (H - b.height * s) / 2)
        cv.drawBitmap(b, m, Paint(Paint.FILTER_BITMAP_FLAG))
    }

    private fun stats(cv: Canvas, p: Paint, a: Act, y: Float, big: Float, ink: Int, mu: Int) {
        p.style = Paint.Style.FILL; p.typeface = Typeface.DEFAULT_BOLD
        fun t(s: String, x: Float, yy: Float, size: Float, c: Int) { p.color = c; p.textSize = size; cv.drawText(s, x, yy, p) }
        t("Distance", 64f, y, 32f, mu); t("%.2f km".format(a.km), 64f, y + big * 0.9f, big, ink)
        val y2 = y + big * 0.9f + 70f
        t("Pace", 64f, y2, 30f, mu); t(fmtP(a.dur / a.km) + " /km", 64f, y2 + 62f, 54f, ink)
        t("Time", 420f, y2, 30f, mu); t(fmtT(a.dur), 420f, y2 + 62f, 54f, ink)
        if (a.elev > 0) { t("Elevation", 740f, y2, 30f, mu); t("${a.elev} m", 740f, y2 + 62f, 54f, ink) }
        else if (a.steps > 0) { t("Steps", 740f, y2, 30f, mu); t("${a.steps}", 740f, y2 + 62f, 54f, ink) }
    }

    /** style: 0 map card, 1 dark map card, 2 transparent sticker, 3 photo story */
    fun render(a: Act, style: Int, map: MapImg?, photo: Bitmap?): Bitmap {
        val sticker = style == 2; val story = style == 3; val dark = style == 1; val light = style == 0
        val W = 1080; val H = if (story) 1920 else if (sticker) 1080 else 1350
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
        val ink = if (light) 0xFF242428.toInt() else Color.WHITE
        val mu = if (light) 0xFF62626C.toInt() else if (dark) 0xFFA5ABB5.toInt() else 0xDDFFFFFF.toInt()
        val orange = 0xFFFC4C02.toInt(); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        if (story) {
            cv.drawColor(0xFF222222.toInt()); if (photo != null) cover(cv, photo, W, H)
            p.shader = LinearGradient(0f, H * .45f, 0f, H.toFloat(), 0x00000000, 0xDD000000.toInt(), Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p); p.shader = null
        } else if (!sticker) cv.drawColor(if (dark) 0xFF14161A.toInt() else Color.WHITE)
        if (light || dark) {
            val pts: List<PointF>
            if (map != null) {
                val q = Paint(Paint.ANTI_ALIAS_FLAG)
                if (dark) q.colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(-0.9f, 0f, 0f, 0f, 235f, 0f, -0.9f, 0f, 0f, 240f, 0f, 0f, -0.9f, 0f, 250f, 0f, 0f, 0f, 1f, 0f)))
                cv.drawBitmap(map.bmp, 0f, 0f, q); pts = a.route.map { map.proj(it.lat, it.lon) }
            } else { grid(cv, RectF(0f, 0f, W.toFloat(), MH.toFloat()), dark); pts = fit(a.route, RectF(110f, 110f, W - 110f, MH - 110f)) }
            route(cv, pts, orange, null, 15f)
            p.typeface = Typeface.DEFAULT_BOLD; p.color = ink; p.textSize = 62f; cv.drawText(title(a), 64f, 880f, p)
            p.color = mu; p.textSize = 34f; p.typeface = Typeface.DEFAULT; cv.drawText(fmtD(a.start), 64f, 936f, p)
            stats(cv, p, a, 1000f, 120f, ink, mu)
            p.typeface = Typeface.DEFAULT_BOLD; p.color = orange; p.textSize = 44f; cv.drawText("Stride", 64f, 1314f, p)
        } else {
            p.setShadowLayer(10f, 0f, 4f, 0x99000000.toInt())
            if (sticker) {
                route(cv, fit(a.route, RectF(120f, 40f, W - 120f, 600f)), orange, Color.WHITE, 18f)
                stats(cv, p, a, 700f, 120f, ink, mu); p.color = Color.WHITE; p.textSize = 44f; p.typeface = Typeface.DEFAULT_BOLD; cv.drawText("Stride", 64f, 1030f, p)
            } else {
                route(cv, fit(a.route, RectF(120f, 980f, W - 120f, 1420f)), orange, Color.WHITE, 18f)
                p.typeface = Typeface.DEFAULT_BOLD; p.color = ink; p.textSize = 54f; cv.drawText(title(a), 64f, 1500f, p)
                stats(cv, p, a, 1560f, 130f, ink, mu); p.color = Color.WHITE; p.textSize = 44f; p.typeface = Typeface.DEFAULT_BOLD; cv.drawText("Stride", 64f, 1880f, p)
            }
            p.clearShadowLayer()
        }
        return bmp
    }

    fun share(c: Context, a: Act, b: Bitmap) {
        val f = File(File(c.cacheDir, "share").apply { mkdirs() }, "stride_${a.id}_${System.currentTimeMillis()}.png")
        f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val u = FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, u)
            .putExtra(Intent.EXTRA_TEXT, "${title(a)}: ${"%.2f".format(a.km)} km in ${fmtT(a.dur)} #Stride").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(i, "Share activity"))
    }

    fun save(c: Context, b: Bitmap): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "stride_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Stride")
        }
        val u = c.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        c.contentResolver.openOutputStream(u)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return true
    }
}
