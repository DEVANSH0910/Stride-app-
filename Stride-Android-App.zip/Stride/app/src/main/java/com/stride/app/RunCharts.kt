package com.stride.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable fun RunChart(title: String, x: List<Float>, y: List<Float>, color: Color, fmt: (Float) -> String, summary: String, flip: Boolean = false) {
    val n = y.size
    if (n < 3) return
    var sel by remember { mutableStateOf(-1) }
    val lo = y.minOrNull() ?: 0f; val hi = y.maxOrNull() ?: 1f
    val x0 = x.first(); val span = x.last() - x0
    fun fx(i: Int) = if (span > 0.001f) (x[i] - x0) / span else i / (n - 1f)
    Spacer(Modifier.height(12.dp))
    Card2 {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(if (sel >= 0) fmt(y[sel]) + " · " + "%.2f km".format(x[sel]) else summary, color = Mu, fontSize = 13.sp)
            }
            Canvas(Modifier.fillMaxWidth().height(140.dp).padding(top = 10.dp).pointerInput(n) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> sel = (o.x / size.width * (n - 1)).roundToInt().coerceIn(0, n - 1) },
                    onDragEnd = { sel = -1 }, onDragCancel = { sel = -1 },
                    onHorizontalDrag = { c, _ -> sel = (c.position.x / size.width * (n - 1)).roundToInt().coerceIn(0, n - 1) })
            }) {
                val w = size.width; val h = size.height
                fun py(v: Float): Float { var t = (v - lo) / maxOf(hi - lo, 1e-3f); if (flip) t = 1f - t; return h * (0.08f + 0.84f * (1f - t)) }
                for (g in listOf(0.08f, 0.5f, 0.92f)) drawLine(Line, Offset(0f, h * g), Offset(w, h * g), 2f)
                val line = Path(); val fill = Path()
                for (i in 0 until n) {
                    val px = fx(i) * w; val pyv = py(y[i])
                    if (i == 0) { line.moveTo(px, pyv); fill.moveTo(px, h); fill.lineTo(px, pyv) } else { line.lineTo(px, pyv); fill.lineTo(px, pyv) }
                }
                fill.lineTo(w, h); fill.close()
                drawPath(fill, color.copy(alpha = 0.18f)); drawPath(line, color, style = Stroke(5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                if (sel >= 0) {
                    val px = fx(sel) * w
                    drawLine(Mu, Offset(px, 0f), Offset(px, h), 3f); drawCircle(color, 11f, Offset(px, py(y[sel])))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), Arrangement.SpaceBetween) {
                Text("%.1f km".format(x.first()), fontSize = 11.sp, color = Mu); Text("%.1f km".format(x.last()), fontSize = 11.sp, color = Mu)
            }
        }
    }
}

private fun smooth(l: List<Float>, w: Int) = l.indices.map { i ->
    l.subList(maxOf(0, i - w / 2), minOf(l.lastIndex, i + w / 2) + 1).average().toFloat()
}

@Composable fun RunCharts(a: Act) {
    val ctx = LocalContext.current
    val ser = a.series ?: emptyList()
    var hr by remember { mutableStateOf<List<Pair<Int, Int>>>(emptyList()) }
    LaunchedEffect(a.id) { hr = HealthSync.heart(ctx, a) }
    if (ser.size >= 3) {
        val xs = ser.map { it.km }
        val spd = smooth(ser.map { it.v * 3.6f }, 7)
        val pace = spd.map { if (it < 1f) 900f else minOf(3600f / it, 900f) }
        RunChart("Pace", xs, pace, Org, { fmtP(it.toDouble()) + " /km" }, "Avg ${fmtP(a.dur / a.km)} · Best ${fmtP((pace.minOrNull() ?: 0f).toDouble())} /km", flip = true)
        RunChart("Speed", xs, spd, Color(0xFF2F6BFF), { "%.1f km/h".format(it) }, "Avg %.1f · Max %.1f km/h".format(a.km / (a.dur / 3600.0), spd.maxOrNull() ?: 0f))
        val alt = ser.map { it.alt }
        val first = alt.firstOrNull { it > -900f }
        if (first != null && alt.count { it > -900f } >= 3) {
            val rel = smooth(alt.map { if (it > -900f) it - first else 0f }, 5)
            RunChart("Elevation", xs, rel, Color(0xFF1E9E4F), { "%+.0f m".format(it) }, "Gain ${a.elev} m · High %+.0f m".format(rel.maxOrNull() ?: 0f))
        }
    }
    if (hr.size >= 3) {
        val step = maxOf(1, hr.size / 300); val h = hr.filterIndexed { i, _ -> i % step == 0 }
        val xs = h.map { p -> if (ser.isNotEmpty()) (ser.minByOrNull { abs(it.t - p.first) }?.km ?: 0f) else (a.km * p.first / maxOf(a.dur, 1)).toFloat() }
        RunChart("Heart rate", xs, h.map { it.second.toFloat() }, Color(0xFFE5484D), { "${it.toInt()} bpm" }, "Avg ${h.map { it.second }.average().toInt()} · Max ${h.maxOf { it.second }} bpm")
    }
}
