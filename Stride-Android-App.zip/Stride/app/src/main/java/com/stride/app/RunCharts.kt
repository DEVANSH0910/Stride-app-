package com.stride.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun smpOf(a: Act): List<Sample> = a.series.orEmpty()

private fun avgWin(v: List<Float>, w: Int): List<Float> = v.indices.map { i ->
    val s = maxOf(0, i - w / 2); val e = minOf(v.size - 1, i + w / 2); v.subList(s, e + 1).average().toFloat()
}

@Composable fun ChartBox(title: String, xs: List<Float>, ys: List<Float>, color: Color, paceStyle: Boolean, fmt: (Float) -> String, sub: String) {
    var sel by remember { mutableStateOf<Int?>(null) }
    val lo = ys.min(); val hi = ys.max(); val xMax = maxOf(xs.last(), 0.01f)
    fun idx(x: Float, w: Int): Int {
        val t = (x / w).coerceIn(0f, 1f) * xMax; var b = 0; var bd = Float.MAX_VALUE
        for (i in xs.indices) { val d = Math.abs(xs[i] - t); if (d < bd) { bd = d; b = i } }
        return b
    }
    Column(Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(14.dp)).background(Bg).padding(14.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(sel?.let { "${"%.2f".format(xs[it])} km · ${fmt(ys[it])}" } ?: sub, color = Mu, fontSize = 12.sp)
        }
        Canvas(Modifier.fillMaxWidth().height(130.dp).padding(top = 10.dp).pointerInput(xs) {
            detectHorizontalDragGestures(onDragStart = { sel = idx(it.x, size.width) }, onDragEnd = { sel = null }, onDragCancel = { sel = null }) { ch, _ -> sel = idx(ch.position.x, size.width) }
        }) {
            val rng = maxOf(hi - lo, 0.001f)
            fun px(i: Int) = size.width * xs[i] / xMax
            fun yOf(v: Float): Float { val n = (v - lo) / rng; return size.height * (0.08f + 0.84f * (if (paceStyle) n else 1f - n)) }
            val line = Path(); val area = Path()
            ys.indices.forEach { i ->
                if (i == 0) { line.moveTo(px(0), yOf(ys[0])); area.moveTo(px(0), size.height); area.lineTo(px(0), yOf(ys[0])) }
                else { line.lineTo(px(i), yOf(ys[i])); area.lineTo(px(i), yOf(ys[i])) }
            }
            area.lineTo(px(ys.size - 1), size.height); area.close()
            drawPath(area, color.copy(alpha = 0.16f))
            drawPath(line, color, style = Stroke(5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            val ay = yOf(ys.average().toFloat())
            drawLine(color.copy(alpha = 0.5f), Offset(0f, ay), Offset(size.width, ay), 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
            sel?.let { drawLine(Ink, Offset(px(it), 0f), Offset(px(it), size.height), 2f); drawCircle(color, 10f, Offset(px(it), yOf(ys[it]))) }
        }
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Text("0 km", fontSize = 11.sp, color = Mu); Text("%.1f km".format(xMax), fontSize = 11.sp, color = Mu)
        }
    }
}

@Composable fun RunCharts(a: Act) {
    val ctx = LocalContext.current
    val sm = smpOf(a)
    var hr by remember { mutableStateOf<List<Pair<Int, Int>>>(emptyList()) }
    LaunchedEffect(a.id) { hr = HealthSync.heart(ctx, a) }
    var any = false
    if (sm.size >= 6) {
        val xs = ArrayList<Float>(); val pace = ArrayList<Float>(); val spd = ArrayList<Float>()
        for (i in 4 until sm.size) {
            val dd = (sm[i].km - sm[i - 4].km) * 1000f; val dt = sm[i].t - sm[i - 4].t
            if (dt > 0 && dd > 1f) { val v = dd / dt; xs.add(sm[i].km); spd.add(v * 3.6f); pace.add(minOf(1000f / v, 1200f)) }
        }
        if (xs.size >= 2) {
            any = true
            val ps = avgWin(pace, 5); val ss = avgWin(spd, 5)
            ChartBox("Pace", xs, ps, Org, true, { fmtP(it.toDouble()) + " /km" }, "Avg ${fmtP(a.dur / a.km)} /km · Best ${fmtP(ps.min().toDouble())}")
            ChartBox("Speed", xs, ss, Color(0xFF2F9E6B), false, { "%.1f km/h".format(it) }, "Avg %.1f · Max %.1f km/h".format(a.km / (a.dur / 3600.0), ss.max()))
        }
    }
    if (hr.size >= 3) {
        any = true
        val xh = hr.map { (t, _) -> if (sm.isNotEmpty()) (sm.firstOrNull { it.t >= t } ?: sm.last()).km else (a.km * t / maxOf(a.dur, 1)).toFloat() }
        val yh = hr.map { it.second.toFloat() }
        ChartBox("Heart rate", xh, avgWin(yh, 5), Color(0xFFE5484D), false, { "${it.toInt()} bpm" }, "Avg ${yh.average().toInt()} · Max ${yh.max().toInt()} bpm")
    }
    if (!any && a.src == "stride") Text("Charts appear for activities recorded with this version of Stride.", color = Mu, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
}
