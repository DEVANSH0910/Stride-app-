package com.stride.app

import android.graphics.*
import java.text.SimpleDateFormat
import java.util.*

object Overlays {
    val names = listOf("Ring", "Block", "Date", "Footer", "Swoosh", "Track", "Bands", "Stack", "Minimal", "Route")
    val cards = listOf("Map", "Dark map", "Pace chart")
    private const val GRAY = 0xFFA5ABB5.toInt()

    private fun pz(sec: Double): String {
        if (sec.isNaN() || sec.isInfinite() || sec <= 0 || sec > 1800) return "--"
        val r = sec.toInt(); return "%02d'%02d\"".format(r / 60, r % 60)
    }
    private fun t(cv: Canvas, s: String, x: Float, y: Float, size: Float, col: Int = Color.WHITE, bold: Boolean = true, al: Paint.Align = Paint.Align.LEFT) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG); p.textSize = size; p.color = col; p.textAlign = al
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT; cv.drawText(s, x, y, p)
    }
    private fun tu(cv: Canvas, num: String, unit: String, x: Float, y: Float, size: Float, col: Int = Color.WHITE) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG); p.textSize = size; p.typeface = Typeface.DEFAULT_BOLD; p.color = col
        cv.drawText(num, x, y, p); val w = p.measureText(num); p.textSize = size * 0.4f; cv.drawText(unit, x + w + 14f, y, p)
    }
    private fun stroke(w: Float, col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = w; color = col; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private fun fill(col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col }
    private fun line(cv: Canvas, pts: List<PointF>, col: Int, w: Float) {
        if (pts.size < 2) return
        val p = Path(); pts.forEachIndexed { i, o -> if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }; cv.drawPath(p, stroke(w, col))
    }

    fun draw(cv: Canvas, W: Int, H: Int, a: Act, d: Int, c: Int) {
        val w = W.toFloat(); val h = H.toFloat(); val km = "%.2f".format(a.km); val pace = pz(a.dur / a.km); val dur = fmtT(a.dur)
        val onC = if (c == Color.WHITE) 0xFF14161A.toInt() else Color.WHITE
        when (d) {
            0 -> { // Ring
                t(cv, "Stride", 56f, 110f, 54f)
                tu(cv, km, "km", 70f, h * .50f, 330f)
                cv.save(); cv.rotate(-14f, w / 2, h * .62f); cv.drawOval(RectF(w * .12f, h * .44f, w * .98f, h * .76f), stroke(44f, c)); cv.restore()
                t(cv, "DURATION  $dur", 80f, h * .86f, 62f, Color.WHITE, false); t(cv, "AVG. PACE  $pace", 80f, h * .86f + 76f, 62f, Color.WHITE, false)
            }
            1 -> { // Block
                val p = Path(); p.fillType = Path.FillType.EVEN_ODD
                p.addRoundRect(RectF(0f, 0f, w, h), 70f, 70f, Path.Direction.CW); p.addOval(RectF(w * .16f, h * .22f, w * .98f, h * .88f), Path.Direction.CW)
                cv.drawPath(p, fill(c))
                tu(cv, km, "km", 60f, h * .2f, 250f, onC)
                line(cv, ShareCard.fit(a.route, RectF(w * .4f, h * .4f, w * .8f, h * .74f)), onC, 7f)
                t(cv, pace, 60f, h - 55f, 64f, onC); t(cv, dur, w - 60f, h - 55f, 64f, onC, true, Paint.Align.RIGHT)
            }
            2 -> { // Date
                val cal = Calendar.getInstance().apply { timeInMillis = a.start }
                t(cv, cal.get(Calendar.DAY_OF_MONTH).toString(), 40f, h * .5f, 600f, c)
                t(cv, SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(Date(a.start)).uppercase(), 70f, h * .5f + 110f, 84f)
                t(cv, "$km km", 70f, h - 110f, 78f); t(cv, dur, w * .55f, h - 110f, 78f)
            }
            3 -> { // Footer
                val y = h - 120f
                line(cv, ShareCard.fit(a.route, RectF(60f, y - 100f, 230f, y + 30f)), Color.WHITE, 7f)
                listOf("Distance" to "$km km", "Duration" to dur, "Avg. pace" to pace).forEachIndexed { i, (l, v) ->
                    val x = 290f + i * 270f; t(cv, l, x, y - 50f, 32f, 0xCCFFFFFF.toInt(), false); t(cv, v, x, y + 22f, 62f)
                }
            }
            4 -> { // Swoosh
                tu(cv, km, "km", 60f, h * .3f, 300f)
                val p = Path(); p.moveTo(w * .02f, h * .55f); p.cubicTo(w * .65f, h * .38f, w * .15f, h * .88f, w * 1.03f, h * .72f)
                cv.drawPath(p, stroke(150f, (c and 0x00FFFFFF) or 0x33000000)); cv.drawPath(p, stroke(96f, c))
                t(cv, "DURATION  $dur", 60f, h - 150f, 54f, Color.WHITE, false); t(cv, "AVG. PACE  $pace", 60f, h - 80f, 54f, Color.WHITE, false)
            }
            5 -> { // Track
                for (i in 0..5) {
                    val rc = RectF(40f + i * 34f, h * .2f + i * 34f, w - 40f - i * 34f, h * .66f - i * 34f)
                    cv.drawRoundRect(rc, rc.height() / 2, rc.height() / 2, stroke(12f, 0xDDFFFFFF.toInt()))
                }
                t(cv, km, w / 2, h * .46f, 240f, Color.WHITE, true, Paint.Align.CENTER); t(cv, "km", w / 2, h * .46f + 80f, 70f, Color.WHITE, false, Paint.Align.CENTER)
                t(cv, "Duration", 60f, h - 130f, 34f, 0xCCFFFFFF.toInt(), false); t(cv, dur, 60f, h - 60f, 66f)
                t(cv, "Avg. pace", w - 60f, h - 130f, 34f, 0xCCFFFFFF.toInt(), false, Paint.Align.RIGHT); t(cv, pace, w - 60f, h - 60f, 66f, Color.WHITE, true, Paint.Align.RIGHT)
            }
            6 -> { // Bands
                cv.save(); cv.rotate(-7f, w / 2, h * .62f); cv.drawRect(-100f, h * .58f, w + 100f, h * .66f, fill(c))
                t(cv, "AVG. PACE  $pace", 120f, h * .58f + h * .055f, 60f, onC); cv.restore()
                cv.save(); cv.rotate(7f, w / 2, h * .82f); cv.drawRect(-100f, h * .78f, w + 100f, h * .86f, fill(c))
                t(cv, "DISTANCE  $km KM", w - 120f, h * .78f + h * .055f, 60f, onC, true, Paint.Align.RIGHT); cv.restore()
            }
            7 -> { // Stack
                val cx = w / 2
                t(cv, "Stride", cx, h * .2f, 52f, Color.WHITE, true, Paint.Align.CENTER)
                listOf("Distance" to "$km km", "Duration" to dur, "Avg. pace" to pace).forEachIndexed { i, (l, v) ->
                    val y = h * .36f + i * h * .17f
                    t(cv, l, cx, y, 36f, 0xCCFFFFFF.toInt(), false, Paint.Align.CENTER); t(cv, v, cx, y + 110f, if (i == 0) 130f else 100f, Color.WHITE, true, Paint.Align.CENTER)
                }
            }
            8 -> { // Minimal
                cv.drawCircle(110f, h - 250f, 40f, stroke(12f, c))
                tu(cv, km, "km", 60f, h - 110f, 150f)
                t(cv, "$dur  |  $pace", 64f, h - 40f, 56f, 0xCCFFFFFF.toInt(), false)
            }
            else -> { // Route
                ShareCard.route(cv, ShareCard.fit(a.route, RectF(w * .12f, h * .08f, w * .88f, h * .64f)), Color.WHITE, null, 10f)
                tu(cv, km, "km", 60f, h - 150f, 120f)
                t(cv, "$dur  ·  $pace /km", 64f, h - 70f, 54f, 0xCCFFFFFF.toInt(), false)
            }
        }
    }

    fun compose(a: Act, d: Int, aspect: Int, c: Int, photo: Bitmap?): Bitmap {
        val W = 1080; val H = if (aspect == 0) 1080 else 1920
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
        if (photo != null) { ShareCard.cover(cv, photo, W, H); cv.drawRect(0f, 0f, W.toFloat(), H.toFloat(), fill(0x33000000)) }
        draw(cv, W, H, a, d, c); return bmp
    }

    fun thumb(a: Act, d: Int, c: Int): Bitmap {
        val b = Bitmap.createBitmap(300, 300, Bitmap.Config.ARGB_8888); val cv = Canvas(b)
        cv.drawColor(0xFF8E8E93.toInt()); cv.scale(300f / 1080f, 300f / 1080f); draw(cv, 1080, 1080, a, d, c); return b
    }

    fun card(a: Act, i: Int, map: MapImg?, c: Int): Bitmap = if (i < 2) ShareCard.render(a, i, map, null) else chartCard(a, i == 3, c)

    private fun chartCard(a: Act, elev: Boolean, c: Int): Bitmap {
        val W = 1080; val H = 1350; val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
        cv.drawColor(0xFF14161A.toInt())
        t(cv, title(a), 64f, 130f, 62f); t(cv, fmtD(a.start), 64f, 190f, 34f, GRAY, false)
        tu(cv, "%.2f".format(a.km), "km", 64f, 360f, 170f)
        t(cv, "Time  ${fmtT(a.dur)}    Pace  ${pz(a.dur / a.km)}", 64f, 450f, 44f, GRAY, false)
        val sm = a.series.orEmpty(); val rc = RectF(64f, 600f, W - 64f, 1120f)
        val xs = ArrayList<Float>(); val ys = ArrayList<Float>()
        if (elev) sm.filter { it.alt > -998f }.forEach { xs.add(it.km); ys.add(it.alt) }
        else for (i in 4 until sm.size) {
            val dd = (sm[i].km - sm[i - 4].km) * 1000f; val dt = sm[i].t - sm[i - 4].t
            if (dt > 0 && dd > 1f) { xs.add(sm[i].km); ys.add(minOf(1000f / (dd / dt), 1200f)) }
        }
        if (xs.size < 4) t(cv, "Chart not available for this activity", 64f, 800f, 44f, GRAY, false)
        else {
            val sy = ys.indices.map { i -> ys.subList(maxOf(0, i - 3), minOf(ys.size - 1, i + 3) + 1).average().toFloat() }
            val lo = sy.min(); val rng = maxOf(sy.max() - lo, 0.001f); val xm = maxOf(xs.last(), 0.01f)
            fun px(i: Int) = rc.left + rc.width() * xs[i] / xm
            fun py(v: Float): Float { val n = (v - lo) / rng; return rc.top + rc.height() * (0.06f + 0.88f * (if (elev) 1f - n else n)) }
            val ln = Path(); val ar = Path()
            sy.indices.forEach { i ->
                if (i == 0) { ln.moveTo(px(0), py(sy[0])); ar.moveTo(px(0), rc.bottom); ar.lineTo(px(0), py(sy[0])) } else { ln.lineTo(px(i), py(sy[i])); ar.lineTo(px(i), py(sy[i])) }
            }
            ar.lineTo(px(sy.size - 1), rc.bottom); ar.close()
            cv.drawPath(ar, fill((c and 0x00FFFFFF) or 0x40000000)); cv.drawPath(ln, stroke(8f, c))
            val ay = py(sy.average().toFloat())
            cv.drawLine(rc.left, ay, rc.right, ay, stroke(3f, 0x99FFFFFF.toInt()).apply { pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f) })
            t(cv, "0 km", rc.left, rc.bottom + 50f, 34f, GRAY, false); t(cv, "%.1f km".format(xm), rc.right, rc.bottom + 50f, 34f, GRAY, false, Paint.Align.RIGHT)
            t(cv, if (elev) "Elevation  gain ${a.elev} m" else "Pace  best ${pz(sy.min().toDouble())}   avg ${pz(a.dur / a.km)}", 64f, 560f, 44f)
        }
        t(cv, "Stride", 64f, 1300f, 44f, 0xFFFC4C02.toInt()); return bmp
    }
}
