package com.stride.app

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun ShareScreen(a: Act, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var style by remember { mutableStateOf(0) }
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var map by remember { mutableStateOf<MapImg?>(null) }
    var busy by remember { mutableStateOf(true) }
    LaunchedEffect(a.id) { map = ShareCard.loadMap(a); busy = false }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { photo = ShareCard.loadPhoto(ctx, u); style = 3 } }
    val bmp = remember(a.id, style, map, photo) { if (style == 3 && photo == null) null else ShareCard.render(a, style, map, photo) }
    val names = listOf("Map", "Dark", "Sticker", "Photo")
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("Share activity", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 8.dp))
            TextButton(onClose) { Text("Close", color = Org, fontWeight = FontWeight.Bold) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(16.dp).background(if (style == 2) Color(0xFF7A7F87) else Color.Transparent), Alignment.Center) {
            if (bmp != null) Image(bmp.asImageBitmap(), "Preview", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            else Text("Pick a photo to put your stats on", color = Mu)
        }
        if (busy) Text("Loading map…", color = Mu, fontSize = 12.sp, modifier = Modifier.padding(start = 16.dp))
        Row(Modifier.fillMaxWidth().padding(16.dp), Arrangement.spacedBy(8.dp)) {
            names.forEachIndexed { i, n ->
                val sel = style == i
                Box(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(if (sel) Org else Line)
                    .clickable { if (i == 3 && photo == null) pick.launch("image/*") else style = i }.padding(vertical = 10.dp), Alignment.Center) {
                    Text(n, color = if (sel) Color.White else Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp), Arrangement.spacedBy(10.dp)) {
            Button({ bmp?.let { ShareCard.share(ctx, a, it) } }, Modifier.weight(1f), enabled = bmp != null, colors = ButtonDefaults.buttonColors(containerColor = Org)) { Text("Share", fontWeight = FontWeight.Bold) }
            OutlinedButton({ bmp?.let { Toast.makeText(ctx, if (ShareCard.save(ctx, it)) "Saved to Pictures/Stride" else "Could not save", Toast.LENGTH_SHORT).show() } }, Modifier.weight(1f), enabled = bmp != null) { Text("Save") }
        }
    }
}
