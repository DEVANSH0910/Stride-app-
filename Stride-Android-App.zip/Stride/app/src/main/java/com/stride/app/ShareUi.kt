package com.stride.app

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File

private val Panel = Color(0xFF2A2D33)

@Composable private fun Opt(sel: Boolean, m: Modifier = Modifier, on: () -> Unit, c: @Composable BoxScope.() -> Unit) =
    Box(m.clip(RoundedCornerShape(14.dp)).background(Panel).then(if (sel) Modifier.border(3.dp, Org, RoundedCornerShape(14.dp)) else Modifier).clickable(onClick = on), Alignment.Center, content = c)

@Composable private fun Grid(bm: List<Bitmap>, labels: List<String>, sel: Int, ratio: Float, pick: (Int) -> Unit) {
    bm.indices.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), Arrangement.spacedBy(10.dp)) {
            row.forEach { i ->
                Column(Modifier.weight(1f)) {
                    Opt(sel == i, Modifier.fillMaxWidth().aspectRatio(ratio), { pick(i) }) { Image(bm[i].asImageBitmap(), labels[i], Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                    Text(labels[i], color = Color(0xFFA5ABB5), fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                }
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable fun ShareScreen(a: Act, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var aspect by remember { mutableStateOf(0) }; var tab by remember { mutableStateOf(0) }
    var design by remember { mutableStateOf(0) }; var card by remember { mutableStateOf(0) }; var accIdx by remember { mutableStateOf(0) }
    var photo by remember { mutableStateOf<Bitmap?>(null) }; var map by remember { mutableStateOf<MapImg?>(null) }
    LaunchedEffect(a.id) { map = ShareCard.loadMap(a) }
    val accents = listOf(0xFFFC4C02.toInt(), 0xFF3DDC3A.toInt(), 0xFF3B82F6.toInt(), 0xFFFFFFFF.toInt()); val acc = accents[accIdx]
    val gal = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) photo = ShareCard.loadPhoto(ctx, u) }
    val camFile = remember { File(File(ctx.cacheDir, "share").apply { mkdirs() }, "camera.jpg") }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) photo = ShareCard.loadPhoto(ctx, FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", camFile))
    }
    val out = remember(a.id, tab, design, card, aspect, acc, photo, map) { if (tab == 0) Overlays.compose(a, design, aspect, acc, photo) else Overlays.card(a, card, map, acc) }
    val thumbs = remember(a.id, acc) { Overlays.names.indices.map { Overlays.thumb(a, it, acc) } }
    val cardThumbs = remember(a.id, acc, map) { Overlays.cards.indices.map { Bitmap.createScaledBitmap(Overlays.card(a, it, map, acc), 300, 375, true) } }
    Column(Modifier.fillMaxSize().background(Color(0xFF14161A))) {
        Row(Modifier.fillMaxWidth().padding(10.dp), Arrangement.Center) {
            Row(Modifier.clip(RoundedCornerShape(22.dp)).background(Panel)) {
                listOf("1:1", "9:16").forEachIndexed { i, n ->
                    Box(Modifier.clip(RoundedCornerShape(22.dp)).background(if (aspect == i) Color(0xFFE6E6EA) else Color.Transparent).clickable { aspect = i; tab = 0 }.padding(horizontal = 28.dp, vertical = 10.dp)) {
                        Text(n, color = if (aspect == i) Color(0xFF14161A) else Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), Alignment.Center) {
            Box(Modifier.aspectRatio(out.width / out.height.toFloat()).clip(RoundedCornerShape(6.dp))) {
                if (tab == 0 && photo == null) Canvas(Modifier.matchParentSize()) {
                    val s = 28f; var y = 0f; var r = 0
                    while (y < size.height) { var x = 0f; var k = r; while (x < size.width) { drawRect(if (k % 2 == 0) Color(0xFF9A9A9A) else Color(0xFF858585), Offset(x, y), Size(s, s)); x += s; k++ }; y += s; r++ }
                }
                Image(out.asImageBitmap(), "Preview", Modifier.matchParentSize(), contentScale = ContentScale.Fit)
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.SpaceEvenly) {
            listOf("Image", "Map/Chart").forEachIndexed { i, n ->
                Text(n, color = if (tab == i) Color.White else Color(0xFF8E939C), fontWeight = FontWeight.Bold, fontSize = 17.sp,
                    modifier = Modifier.clickable { tab = i; if (i == 1) aspect = 0 }.padding(8.dp))
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp)) {
            if (tab == 0) {
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), Arrangement.spacedBy(10.dp)) {
                    Opt(photo == null, Modifier.weight(1f).height(64.dp), { photo = null }) { Text("Transparent", color = Color.White, fontSize = 12.sp) }
                    Opt(false, Modifier.weight(1f).height(64.dp), { gal.launch("image/*") }) { Text("Gallery", color = Color.White, fontSize = 13.sp) }
                    Opt(false, Modifier.weight(1f).height(64.dp), { camFile.createNewFile(); cam.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", camFile)) }) { Text("Camera", color = Color.White, fontSize = 13.sp) }
                }
                Text("Preset overlays", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(bottom = 8.dp))
                Grid(thumbs, Overlays.names, design, 1f) { design = it }
                Text("Color", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(vertical = 4.dp))
                Row(Modifier.padding(bottom = 12.dp), Arrangement.spacedBy(14.dp)) {
                    accents.forEachIndexed { i, col ->
                        Box(Modifier.size(38.dp).clip(CircleShape).background(Color(col)).then(if (accIdx == i) Modifier.border(3.dp, Color.White, CircleShape) else Modifier).clickable { accIdx = i })
                    }
                }
            } else Grid(cardThumbs, Overlays.cards, card, 0.8f) { card = it }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), Arrangement.Center) {
            Row(Modifier.clip(RoundedCornerShape(30.dp)).background(Panel).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Cancel", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onClose).padding(horizontal = 22.dp, vertical = 16.dp))
                Text("Save", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                    Toast.makeText(ctx, if (ShareCard.save(ctx, out)) "Saved to Pictures/Stride" else "Could not save", Toast.LENGTH_SHORT).show()
                }.padding(horizontal = 22.dp, vertical = 16.dp))
                Text("Share", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { ShareCard.share(ctx, a, out) }.padding(horizontal = 22.dp, vertical = 16.dp))
            }
        }
    }
}
