package com.stride.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.PermissionController
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Configuration.getInstance().load(applicationContext, getSharedPreferences("osm", 0))
        Configuration.getInstance().userAgentValue = packageName
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var acts by remember { mutableStateOf(Store.all(ctx)) }
    var tab by remember { mutableStateOf(0) }
    var det by remember { mutableStateOf<Long?>(null) }
    var steps by remember { mutableStateOf<Long?>(null) }
    var msg by remember { mutableStateOf("") }
    var goal by remember { mutableStateOf(Store.goal(ctx)) }
    var updDismissed by remember { mutableStateOf(false) }
    val upd by Updater.s.collectAsState()
    LaunchedEffect(Unit) { Updater.check(false) }
    var hd by remember { mutableStateOf<HD?>(null) }
    LaunchedEffect(tab) { if (tab == 3) hd = HealthSync.load(ctx) }
    var theme by remember { mutableStateOf(Store.theme(ctx)) }
    var shareAct by remember { mutableStateOf<Act?>(null) }
    val ts by Track.s.collectAsState(); val done by Track.done.collectAsState()
    LaunchedEffect(done) { done?.let { acts = Store.all(ctx); det = it; tab = 0; Track.done.value = null } }
    LaunchedEffect(ts.on) { if (ts.on) { tab = 2; det = null } }
    LaunchedEffect(Unit) { steps = HealthSync.steps(ctx) }

    val share = { a: Act -> shareAct = a }
    val send = { a: String ->
        val i = Intent(ctx, TrackingService::class.java).setAction(a)
        if (a == "START") ctx.startForegroundService(i) else ctx.startService(i)
    }
    val locL = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) send("START")
    }
    val onStart = {
        val need = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 29) need.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { ctx.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) send("START") else locL.launch(missing.toTypedArray())
    }
    val hcL = rememberLauncherForActivityResult(PermissionController.createRequestPermissionResultContract()) { g ->
        msg = if (g.containsAll(HealthSync.core)) "Connected to Health Connect" else "Permission not granted"
        scope.launch { steps = HealthSync.steps(ctx); hd = HealthSync.load(ctx) }
    }

    val connectHC = { if (!HealthSync.available(ctx)) msg = "Install or update Health Connect from the Play Store" else hcL.launch(HealthSync.perms) }
    val dark = when (theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    Pal.dark = dark
    val view = LocalView.current
    SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = Bg.toArgb(); w.navigationBarColor = Surf.toArgb()
        val ic = WindowCompat.getInsetsController(w, view); ic.isAppearanceLightStatusBars = !dark; ic.isAppearanceLightNavigationBars = !dark
    }
    key(dark) {
    CompositionLocalProvider(LocalContentColor provides Ink) {
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Org, onPrimary = Color.White) else lightColorScheme(primary = Org)) {
        if (upd.avail && !updDismissed) AlertDialog(
            onDismissRequest = { if (upd.progress < 0) updDismissed = true },
            title = { Text("Update available") },
            text = {
                Column {
                    Text("A new version of Stride (build ${upd.code}) is ready." + if (upd.notes.isNotEmpty()) "\n\n${upd.notes}" else "")
                    if (upd.progress >= 0) {
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(progress = { upd.progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Org)
                        Text("Downloading ${upd.progress}%", fontSize = 13.sp, color = Mu)
                    }
                    if (upd.msg.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(upd.msg, color = Org, fontSize = 13.sp) }
                }
            },
            confirmButton = { TextButton({ scope.launch { Updater.download(ctx) } }, enabled = upd.progress < 0) { Text("Update now") } },
            dismissButton = { TextButton({ updDismissed = true }, enabled = upd.progress < 0) { Text("Later") } })
        Column(Modifier.fillMaxSize().background(Bg)) {
            Box(Modifier.weight(1f)) {
                val d = acts.find { it.id == det }
                if (shareAct != null) ShareScreen(shareAct!!) { shareAct = null }
                else if (d != null) Detail(d, { det = null }, { Store.save(ctx, acts.filter { it.id != d.id }); acts = Store.all(ctx); det = null }, { share(d) })
                else when (tab) {
                    0 -> Home(acts, goal, { det = it }, share)
                    1 -> Routes(acts)
                    2 -> Record(ts) { a -> if (a == "START") onStart() else send(a) }
                    3 -> Goals(acts, goal, hd, connectHC) { goal = it; Store.setGoal(ctx, it) }
                    else -> You(acts, steps, msg, theme, { theme = it; Store.setTheme(ctx, it) },
                        { if (!HealthSync.available(ctx)) msg = "Install or update Health Connect from the Play Store" else hcL.launch(HealthSync.perms) },
                        { scope.launch { val n = HealthSync.import(ctx); acts = Store.all(ctx); msg = "Imported $n workouts from Health Connect" } },
                        upd, { updDismissed = false; scope.launch { Updater.check(true) } })
                }
            }
            NavBar(tab) { tab = it; det = null }
        }
    }
    }
    }
}
