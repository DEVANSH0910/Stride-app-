package com.stride.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.*
import com.google.android.gms.location.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

data class TS(val on: Boolean = false, val paused: Boolean = false, val elapsed: Int = 0, val km: Double = 0.0,
              val pts: List<Pt> = emptyList(), val nowPace: Int = 0, val kind: Int = -1, val gps: Boolean = false,
              val steps: Int = 0, val gain: Int = 0)

object Track {
    val s = MutableStateFlow(TS())
    val done = MutableStateFlow<Long?>(null)
}

class TrackingService : Service(), SensorEventListener {
    private lateinit var fused: FusedLocationProviderClient
    private val h = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    // smoothed (Kalman) position and the last accepted point
    private var kLat = 0.0; private var kLon = 0.0; private var kV = -1.0; private var kT = 0L
    private var have = false; private var aLat = 0.0; private var aLon = 0.0; private var aT = 0L
    private val sp = DoubleArray(3)
    private val splits = mutableListOf<Int>()
    private var lastSplit = 0
    private val rec = ArrayDeque<Pair<Int, Double>>()
    private var startTs = 0L
    private val samples = ArrayList<Sample>()
    private var calibF = 1.0
    private var pLat = 0.0; private var pLon = 0.0
    // elevation and steps
    private var baro: Double? = null; private var gAlt = Double.NaN
    private var ref = Double.NaN; private var gainM = 0.0
    private var lastStep = -1f

    private val tick = object : Runnable {
        override fun run() {
            val s = Track.s.value
            if (s.on && !s.paused) Track.s.value = s.copy(elapsed = s.elapsed + 1)
            h.postDelayed(this, 1000)
        }
    }
    private val cb = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) { r.locations.forEach { onLoc(it) } }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); fused = LocationServices.getFusedLocationProviderClient(this) }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "START" -> start()
            "PAUSE" -> Track.s.value = Track.s.value.copy(paused = true)
            "RESUME" -> { kV = -1.0; have = false; Track.s.value = Track.s.value.copy(paused = false) }
            "FINISH" -> finish()
        }
        return START_NOT_STICKY
    }

    private fun start() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("trk", "Tracking", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "trk").setContentTitle("Stride is tracking your activity")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(1, n)
        kV = -1.0; have = false; sp.fill(0.0); splits.clear(); lastSplit = 0; rec.clear(); samples.clear(); startTs = System.currentTimeMillis()
        baro = null; gAlt = Double.NaN; ref = Double.NaN; gainM = 0.0; lastStep = -1f
        calibF = Store.calib(applicationContext) / 100.0
        Track.s.value = TS(on = true)
        try {
            val sm = getSystemService(SensorManager::class.java)
            sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
            sm.getDefaultSensor(Sensor.TYPE_PRESSURE)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        } catch (e: Exception) { }
        try {
            val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000).setMinUpdateIntervalMillis(1000)
                .setMinUpdateDistanceMeters(0f).setWaitForAccurateLocation(false).build()
            fused.requestLocationUpdates(req, cb, Looper.getMainLooper())
        } catch (e: SecurityException) { }
        h.removeCallbacks(tick); h.post(tick)
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_STEP_COUNTER) {
            val v = e.values[0]; val s = Track.s.value
            if (lastStep >= 0f && s.on && !s.paused) { val d = (v - lastStep).toInt(); if (d > 0) Track.s.value = s.copy(steps = s.steps + d) }
            lastStep = v
        } else if (e.sensor.type == Sensor.TYPE_PRESSURE) {
            val a = SensorManager.getAltitude(SensorManager.PRESSURE_STANDARD_ATMOSPHERE, e.values[0]).toDouble()
            val b = baro; baro = if (b == null) a else b * 0.9 + a * 0.1
        }
    }

    private fun elev(a: Double) {
        if (ref.isNaN()) { ref = a; return }
        if (a - ref >= 3) { gainM += a - ref; ref = a } else if (ref - a >= 3) ref = a
    }

    private fun onLoc(l: Location) {
        val s = Track.s.value
        if (!s.on || s.paused || l.accuracy > 35f) return
        if (!have) {
            have = true; aLat = l.latitude; aLon = l.longitude; aT = l.time; pLat = l.latitude; pLon = l.longitude
            Track.s.value = s.copy(gps = true, pts = s.pts + Pt(l.latitude, l.longitude)); return
        }
        val dt = (l.time - aT) / 1000.0
        if (dt <= 0) return
        val res = FloatArray(1); Location.distanceBetween(aLat, aLon, l.latitude, l.longitude, res)
        val straight = res[0].toDouble()
        val sv: Double; var d: Double
        if (l.hasSpeed() && dt <= 6.0) {
            // GPS Doppler speed is far steadier than position jitter, so distance = speed x time
            sv = l.speed.toDouble(); d = if (sv < 0.5) 0.0 else sv * dt
            aLat = l.latitude; aLon = l.longitude; aT = l.time
        } else {
            sv = straight / dt
            if (straight < maxOf(3.0, l.accuracy * 0.5) || sv < 0.5) return
            d = straight; aLat = l.latitude; aLon = l.longitude; aT = l.time
        }
        if (sv > 12 || d <= 0.0) return
        d *= calibF
        val k = if (sv < 1.9) 0 else if (sv < 2.9) 1 else 2
        sp[k] += dt
        val km = s.km + d / 1000
        samples.add(Sample(s.elapsed, km.toFloat(), -999f, sv.toFloat()))
        if (km.toInt() > s.km.toInt()) { splits.add(s.elapsed - lastSplit); lastSplit = s.elapsed }
        rec.addLast(s.elapsed to km); if (rec.size > 40) rec.removeFirst()
        var np = 0
        if (rec.size > 1) {
            val f = rec[maxOf(0, rec.size - 8)]; val e = rec.last()
            if (e.second > f.second) np = ((e.first - f.first) / (e.second - f.second)).toInt()
        }
        val moved = FloatArray(1); Location.distanceBetween(pLat, pLon, l.latitude, l.longitude, moved)
        val pts = if (moved[0] >= 4f) { pLat = l.latitude; pLon = l.longitude; s.pts + Pt(l.latitude, l.longitude) } else s.pts
        Track.s.value = s.copy(gps = true, km = km, kind = k, nowPace = np, pts = pts)
    }

    private fun finish() {
        val s = Track.s.value
        fused.removeLocationUpdates(cb); h.removeCallbacks(tick)
        try { getSystemService(SensorManager::class.java).unregisterListener(this) } catch (e: Exception) { }
        val k = if (sp.sum() > 0) sp.indices.maxByOrNull { sp[it] }!! else {
            val v = s.km / (maxOf(s.elapsed, 1) / 3600.0); if (v < 6.8) 0 else if (v < 10.4) 1 else 2
        }
        val n = s.pts.size; val step = maxOf(1, (n + 399) / 400)
        val route = s.pts.filterIndexed { i, _ -> i % step == 0 || i == n - 1 }
        if (s.elapsed >= 10 && s.km > 0.01) {
            val sstep = maxOf(1, (samples.size + 299) / 300); val series = samples.filterIndexed { i, _ -> i % sstep == 0 }
            val a = Act(startTs, startTs, s.elapsed, s.km, listOf("Walk", "Jog", "Run")[k], route, splits.toList(), sp.map { it.toInt() }, "stride", s.gain, s.steps, series)
            Store.add(applicationContext, a)
            Track.done.value = a.id
            scope.launch { HealthSync.write(applicationContext, a) }
        }
        Track.s.value = TS()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
}
