package com.stride.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.aggregate.AggregationResult
import androidx.health.connect.client.aggregate.AggregationResultGroupedByPeriod
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.AggregateGroupByPeriodRequest
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.health.connect.client.units.Length
import java.time.*
import java.time.temporal.ChronoUnit

object HealthSync {
    val core = setOf(
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getWritePermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getWritePermission(DistanceRecord::class),
        HealthPermission.getReadPermission(StepsRecord::class))
    val perms = core + setOf(
        HealthPermission.getReadPermission(HeartRateRecord::class), HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class), HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class), HealthPermission.getReadPermission(OxygenSaturationRecord::class))

    fun available(c: Context) = HealthConnectClient.getSdkStatus(c) == HealthConnectClient.SDK_AVAILABLE
    private suspend fun ok(c: Context) = available(c) &&
        HealthConnectClient.getOrCreate(c).permissionController.getGrantedPermissions().containsAll(core)

    suspend fun write(c: Context, a: Act) {
        try {
            if (!ok(c)) return
            val st = Instant.ofEpochMilli(a.start); val en = st.plusSeconds(a.dur.toLong())
            val z = ZoneId.systemDefault().rules.getOffset(st)
            val type = if (a.type == "Walk") ExerciseSessionRecord.EXERCISE_TYPE_WALKING else ExerciseSessionRecord.EXERCISE_TYPE_RUNNING
            HealthConnectClient.getOrCreate(c).insertRecords(listOf(
                ExerciseSessionRecord(startTime = st, startZoneOffset = z, endTime = en, endZoneOffset = z, exerciseType = type, title = "Stride ${a.type}"),
                DistanceRecord(startTime = st, startZoneOffset = z, endTime = en, endZoneOffset = z, distance = Length.meters(a.km * 1000))))
        } catch (e: Exception) { }
    }

    suspend fun steps(c: Context): Long? = try {
        if (!ok(c)) null else {
            val t0 = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()
            HealthConnectClient.getOrCreate(c).aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL),
                TimeRangeFilter.between(t0, Instant.now())))[StepsRecord.COUNT_TOTAL]
        }
    } catch (e: Exception) { null }

    suspend fun import(c: Context): Int = try {
        if (!ok(c)) 0 else {
            val cl = HealthConnectClient.getOrCreate(c); val have = Store.all(c).toMutableList(); var n = 0
            val rs = cl.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class,
                TimeRangeFilter.after(Instant.now().minus(90, ChronoUnit.DAYS)))).records
            for (r in rs) {
                if (r.metadata.dataOrigin.packageName == c.packageName) continue
                val ms = r.startTime.toEpochMilli()
                if (have.any { Math.abs(it.start - ms) < 60000 }) continue
                val dm = cl.aggregate(AggregateRequest(setOf(DistanceRecord.DISTANCE_TOTAL),
                    TimeRangeFilter.between(r.startTime, r.endTime)))[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
                val t = when (r.exerciseType) {
                    ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Walk"
                    ExerciseSessionRecord.EXERCISE_TYPE_RUNNING, ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL -> "Run"
                    ExerciseSessionRecord.EXERCISE_TYPE_BIKING -> "Cycle"
                    else -> "Other"
                }
                have.add(Act(ms, ms, Duration.between(r.startTime, r.endTime).seconds.toInt(), dm / 1000, t,
                    emptyList(), emptyList(), listOf(0, 0, 0), "health")); n++
            }
            Store.save(c, have.sortedByDescending { it.start }); n
        }
    } catch (e: Exception) { 0 }

    private inline fun <T> safe(d: T, f: () -> T): T = try { f() } catch (e: Exception) { d }
    private fun <T> pad(l: List<T>, d: T): List<T> = (List(7) { d } + l).takeLast(7)
    private fun name(p: String) = when (p) {
        "com.sec.android.app.shealth" -> "Samsung Health"; "com.whoop.android" -> "WHOOP"
        "com.google.android.apps.fitness" -> "Google Fit"; "com.google.android.apps.healthdata" -> "Health Connect"
        else -> p.substringAfterLast('.').replaceFirstChar { it.uppercase() }
    }

    suspend fun load(c: Context): HD? = try {
        if (!ok(c)) null else {
            val cl = HealthConnectClient.getOrCreate(c)
            val today = LocalDate.now(); val per = Period.ofDays(1)
            val rng = TimeRangeFilter.between(today.minusDays(6).atStartOfDay(), today.plusDays(1).atStartOfDay())
            val src = mutableSetOf<String>(); val none = listOf<AggregationResultGroupedByPeriod>()
            val sg = safe(none) { cl.aggregateGroupByPeriod(AggregateGroupByPeriodRequest(setOf(StepsRecord.COUNT_TOTAL), rng, per)) }
            val cg = safe(none) { cl.aggregateGroupByPeriod(AggregateGroupByPeriodRequest(setOf(TotalCaloriesBurnedRecord.ENERGY_TOTAL), rng, per)) }
            val lg = safe(none) { cl.aggregateGroupByPeriod(AggregateGroupByPeriodRequest(setOf(SleepSessionRecord.SLEEP_DURATION_TOTAL), rng, per)) }
            val rg = safe(none) { cl.aggregateGroupByPeriod(AggregateGroupByPeriodRequest(setOf(RestingHeartRateRecord.BPM_AVG), rng, per)) }
            for (g in sg + cg + lg + rg) g.result.dataOrigins.forEach { src += it.packageName }
            val t0 = today.atStartOfDay(ZoneId.systemDefault()).toInstant()
            val hr = safe<AggregationResult?>(null) { cl.aggregate(AggregateRequest(setOf(HeartRateRecord.BPM_AVG, HeartRateRecord.BPM_MIN, HeartRateRecord.BPM_MAX), TimeRangeFilter.between(t0, Instant.now()))) }
            hr?.dataOrigins?.forEach { src += it.packageName }
            val w = safe<Double?>(null) { cl.readRecords(ReadRecordsRequest(WeightRecord::class, TimeRangeFilter.after(Instant.now().minus(60, ChronoUnit.DAYS)), ascendingOrder = false, pageSize = 1)).records.firstOrNull()?.weight?.inKilograms }
            val ox = safe<Double?>(null) { cl.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, TimeRangeFilter.after(Instant.now().minus(7, ChronoUnit.DAYS)), ascendingOrder = false, pageSize = 1)).records.firstOrNull()?.percentage?.value }
            HD(pad(sg.map { it.result[StepsRecord.COUNT_TOTAL] ?: 0L }, 0L),
                pad(cg.map { (it.result[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0).toInt() }, 0),
                pad(lg.map { (it.result[SleepSessionRecord.SLEEP_DURATION_TOTAL]?.toMinutes() ?: 0L).toInt() }, 0),
                pad(rg.map { (it.result[RestingHeartRateRecord.BPM_AVG] ?: 0L).toInt() }, 0),
                hr?.get(HeartRateRecord.BPM_AVG), hr?.get(HeartRateRecord.BPM_MIN), hr?.get(HeartRateRecord.BPM_MAX),
                w, ox, src.filter { it != c.packageName }.map { name(it) }.distinct())
        }
    } catch (e: Exception) { null }
}

data class HD(val steps: List<Long>, val cal: List<Int>, val sleep: List<Int>, val rhr: List<Int>,
              val hrAvg: Long?, val hrMin: Long?, val hrMax: Long?, val weight: Double?, val spo2: Double?, val sources: List<String>)
