package com.stride.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.health.connect.client.units.Length
import java.time.*
import java.time.temporal.ChronoUnit

object HealthSync {
    val core = setOf(
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getWritePermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getWritePermission(DistanceRecord::class),
        HealthPermission.getReadPermission(StepsRecord::class))
    val perms = core + HealthPermission.getReadPermission(HeartRateRecord::class)

    fun available(c: Context) = HealthConnectClient.getSdkStatus(c) == HealthConnectClient.SDK_AVAILABLE
    private suspend fun ok(c: Context) = available(c) &&
        HealthConnectClient.getOrCreate(c).permissionController.getGrantedPermissions().containsAll(core)

    suspend fun write(c: Context, a: Act) {
        try {
            if (!ok(c)) return
            val st = Instant.ofEpochMilli(a.start); val en = st.plusSeconds(a.dur.toLong())
            val z = ZoneId.systemDefault().rules.getOffset(st)
            val type = if (a.type == "Walk") ExerciseSessionRecord.EXERCISE_TYPE_WALKING else ExerciseSessionRecord.EXERCISE_TYPE_RUNNING
            HealthConnectClient.getOrCreate(c).insertRecords(listOf(
                ExerciseSessionRecord(startTime = st, startZoneOffset = z, endTime = en, endZoneOffset = z, exerciseType = type, title = "Stride ${a.type}"),
                DistanceRecord(startTime = st, startZoneOffset = z, endTime = en, endZoneOffset = z, distance = Length.meters(a.km * 1000))))
        } catch (e: Exception) { }
    }

    suspend fun steps(c: Context): Long? = try {
        if (!ok(c)) null else {
            val t0 = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()
            HealthConnectClient.getOrCreate(c).aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL),
                TimeRangeFilter.between(t0, Instant.now())))[StepsRecord.COUNT_TOTAL]
        }
    } catch (e: Exception) { null }

    /** Heart-rate samples (seconds from start, bpm) recorded by a watch or band during this activity. */
    suspend fun heart(c: Context, a: Act): List<Pair<Int, Int>> = try {
        if (!ok(c)) emptyList() else {
            val st = Instant.ofEpochMilli(a.start); val en = st.plusSeconds(a.dur.toLong())
            HealthConnectClient.getOrCreate(c).readRecords(ReadRecordsRequest(HeartRateRecord::class, TimeRangeFilter.between(st, en)))
                .records.flatMap { r -> r.samples.map { Pair(Duration.between(st, it.time).seconds.toInt(), it.beatsPerMinute.toInt()) } }
                .filter { it.first in 0..a.dur }.sortedBy { it.first }
        }
    } catch (e: Exception) { emptyList() }

    suspend fun import(c: Context): Int = try {
        if (!ok(c)) 0 else {
            val cl = HealthConnectClient.getOrCreate(c); val have = Store.all(c).toMutableList(); var n = 0
            val rs = cl.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class,
                TimeRangeFilter.after(Instant.now().minus(90, ChronoUnit.DAYS)))).records
            for (r in rs) {
                if (r.metadata.dataOrigin.packageName == c.packageName) continue
                val ms = r.startTime.toEpochMilli()
                if (have.any { Math.abs(it.start - ms) < 60000 }) continue
                val dm = cl.aggregate(AggregateRequest(setOf(DistanceRecord.DISTANCE_TOTAL),
                    TimeRangeFilter.between(r.startTime, r.endTime)))[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
                val t = when (r.exerciseType) {
                    ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Walk"
                    ExerciseSessionRecord.EXERCISE_TYPE_RUNNING, ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL -> "Run"
                    ExerciseSessionRecord.EXERCISE_TYPE_BIKING -> "Cycle"
                    else -> "Other"
                }
                have.add(Act(ms, ms, Duration.between(r.startTime, r.endTime).seconds.toInt(), dm / 1000, t,
                    emptyList(), emptyList(), listOf(0, 0, 0), "health")); n++
            }
            Store.save(c, have.sortedByDescending { it.start }); n
        }
    } catch (e: Exception) { 0 }
}
