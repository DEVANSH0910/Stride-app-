package com.stride.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

fun dayLabels(): List<String> = (6 downTo 0).map { d ->
    val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, -d); "SMTWTFS"[c.get(Calendar.DAY_OF_WEEK) - 1].toString()
}
fun fmtSleep(min: Int) = if (min <= 0) "–" else "${min / 60}h ${min % 60}m"

@Composable fun BarsCard(title: String, values: List<Double>, color: Color, sub: String) {
    val mx = maxOf(values.maxOrNull() ?: 1.0, 1.0); val lb = dayLabels()
    Card2 {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(title, fontWeight = FontWeight.Bold); Text(sub, color = Mu, fontSize = 13.sp) }
            Row(Modifier.fillMaxWidth().height(120.dp).padding(top = 10.dp), Arrangement.spacedBy(8.dp)) {
                values.forEachIndexed { i, v ->
                    Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.Bottom, Alignment.CenterHorizontally) {
                        Box(Modifier.fillMaxWidth().height(maxOf(4.0, v / mx * 84).dp).clip(RoundedCornerShape(6.dp))
                            .background(if (v <= 0) Line else if (i == 6) color else color.copy(alpha = 0.45f)))
                        Text(lb[i], fontSize = 11.sp, color = Mu)
                    }
                }
            }
        }
    }
}

@Composable fun LineCard(title: String, values: List<Int>, color: Color, sub: String) {
    Card2 {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(title, fontWeight = FontWeight.Bold); Text(sub, color = Mu, fontSize = 13.sp) }
            Canvas(Modifier.fillMaxWidth().height(100.dp).padding(top = 12.dp, start = 6.dp, end = 6.dp)) {
                val pts = values.mapIndexedNotNull { i, v -> if (v > 0) i to v else null }
                if (pts.isEmpty()) return@Canvas
                val lo = pts.minOf { it.second } - 2f; val hi = pts.maxOf { it.second } + 2f
                val path = Path()
                pts.forEachIndexed { k, (i, v) ->
                    val x = size.width * i / 6f; val y = size.height * (1f - (v - lo) / (hi - lo))
                    if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, color, style = Stroke(5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                pts.forEach { (i, v) -> drawCircle(color, 8f, Offset(size.width * i / 6f, size.height * (1f - (v - lo) / (hi - lo)))) }
            }
        }
    }
}

@Composable fun HealthSection(h: HD?, connect: () -> Unit) {
    Text("Health", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp))
    if (h == null) {
        Card2 {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Connect your health apps", fontWeight = FontWeight.ExtraBold)
                Text("Samsung Health and WHOOP both save to Health Connect. Connect it and Stride shows your steps, sleep, heart rate and more here, merged in one place.", color = Mu, fontSize = 13.sp)
                Button(connect, colors = ButtonDefaults.buttonColors(containerColor = Org)) { Text("Connect Health Connect") }
            }
        }
        return
    }
    if (h.sources.isNotEmpty()) Text("Sources: " + h.sources.joinToString(" · "), color = Mu, fontSize = 13.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Tile("Steps", "%,d".format(h.steps.last()), Modifier.weight(1f)); Tile("Sleep", fmtSleep(h.sleep.last()), Modifier.weight(1f)); Tile("Calories", "${h.cal.last()}", Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Tile("Resting HR", if (h.rhr.last() > 0) "${h.rhr.last()} bpm" else "–", Modifier.weight(1f))
        Tile("Heart rate", h.hrAvg?.let { "$it bpm" } ?: "–", Modifier.weight(1f))
        Tile("Oxygen", h.spo2?.let { "%.0f%%".format(it) } ?: "–", Modifier.weight(1f))
    }
    BarsCard("Steps", h.steps.map { it.toDouble() }, Org, "%,d avg".format(h.steps.sum() / 7))
    BarsCard("Sleep (hours)", h.sleep.map { it / 60.0 }, Color(0xFF5B7CFA), fmtSleep(h.sleep.filter { it > 0 }.let { if (it.isEmpty()) 0 else it.sum() / it.size }) + " avg")
    BarsCard("Calories burned", h.cal.map { it.toDouble() }, Color(0xFFF5A623), "${h.cal.sum() / 7} avg")
    LineCard("Resting heart rate", h.rhr, Color(0xFFE5484D), if (h.hrMin != null && h.hrMax != null) "Today ${h.hrMin}–${h.hrMax} bpm" else "")
    if (h.weight != null) Tile("Weight", "%.1f kg".format(h.weight))
    Text("Tip: if two apps record the same thing, open Health Connect, then Data and access, to choose which one to prefer.", color = Mu, fontSize = 12.sp)
}
