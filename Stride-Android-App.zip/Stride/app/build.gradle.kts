plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.stride.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.stride.app"; minSdk = 26; targetSdk = 34; versionCode = (System.getenv("VERSION_CODE")?.toIntOrNull() ?: 1); versionName = "1.0"; buildConfigField("String", "REPO", "\"" + (System.getenv("GITHUB_REPOSITORY") ?: "") + "\"") }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    signingConfigs {
        create("stride") { storeFile = file("stride.jks"); storePassword = "stride123"; keyAlias = "stride"; keyPassword = "stride123" }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("stride") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("stride") }
    }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.health.connect:connect-client:1.1.0-alpha07")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("org.osmdroid:osmdroid-android:6.1.18")
    implementation("com.google.code.gson:gson:2.10.1")
}
