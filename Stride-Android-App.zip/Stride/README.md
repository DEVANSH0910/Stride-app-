# Stride – free run, jog and walk tracker for Android
Open this folder in Android Studio (free), wait for Gradle sync, then Run on your phone
(USB debugging on) or Build > Build APK(s) and install the APK. No paid accounts or API keys needed.
Maps: OpenStreetMap via osmdroid. Sync: Health Connect (Samsung Health shares data through it).
